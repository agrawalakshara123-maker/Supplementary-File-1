"""Unit tests with known analytic answers. Run:  python -m pytest -q tests"""
import sys, pathlib
import numpy as np
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import abcd_eye_model as m


def test_single_surface_focus():
    # Parallel ray refracted by one spherical surface focuses at f' = n2 R / (n2 - n1).
    n1, n2, R = 1.0, 1.3771, 7.8e-3
    f_analytic = n2 * R / (n2 - n1)
    M = m.S(n1, n2, R)
    y, th = M @ np.array([1e-3, 0.0])
    f_matrix = -y / th
    assert abs(f_matrix - f_analytic) < 1e-12
    assert abs(f_analytic * 1e3 - 28.4847) < 1e-3          # mm


def test_single_surface_power_from_C():
    n1, n2, R = 1.0, 1.3771, 7.8e-3
    M = m.S(n1, n2, R)
    assert abs(-n2 * M[1, 0] - m.surface_power(n1, n2, R)) < 1e-9
    assert abs(np.linalg.det(M) - n1 / n2) < 1e-12


def test_thin_lens_focus():
    # +10 D thin lens: parallel ray crosses the axis 100 mm behind the lens.
    M = m.T(0.100) @ m.thin_lens(10.0)
    y, _ = M @ np.array([2e-3, 0.0])
    assert abs(y) < 1e-15
    # -5 D lens: virtual focus 200 mm in front, ray angle = +h/0.2
    y, th = m.thin_lens(-5.0) @ np.array([2e-3, 0.0])
    assert abs(th - 2e-3 / 0.2) < 1e-15


def test_thick_lens_in_air_matches_gullstrand_equation():
    n, R1, R2, t = 1.5, 0.05, -0.05, 0.005
    M = m.S(n, 1.0, R2) @ m.T(t) @ m.S(1.0, n, R1)
    P1, P2 = (n - 1) / R1, (1 - n) / R2
    F_gullstrand = P1 + P2 - (t / n) * P1 * P2
    assert abs(-M[1, 0] - F_gullstrand) < 1e-9


def test_physical_and_reduced_conventions_agree():
    # Same system in the reduced convention [y, n*theta]: T = [[1, d/n],[0,1]], S = [[1,0],[-P,1]].
    e = m.LE_GRAND
    surfaces = [(1.0, e["n_cornea"], e["R_corn_ant_mm"]), (e["n_cornea"], e["n_aq"], e["R_corn_post_mm"]),
                (e["n_aq"], e["n_lens"], e["R_lens_ant_mm"]), (e["n_lens"], e["n_vit"], e["R_lens_post_mm"])]
    gaps = [(e["t_corn_mm"], e["n_cornea"]), (e["d_aq_mm"], e["n_aq"]), (e["t_lens_mm"], e["n_lens"])]
    Mr = np.eye(2)
    for i, (n1, n2, R) in enumerate(surfaces):
        Mr = np.array([[1, 0], [-(n2 - n1) / (R * 1e-3), 1]]) @ Mr
        if i < 3:
            d, n = gaps[i]
            Mr = np.array([[1, d * 1e-3 / n], [0, 1]]) @ Mr
    Mp = m.eye_optics_matrix(e)
    assert np.allclose(Mr[0], Mp[0] * np.array([1, 1]))          # A and B (from air, n=1) identical
    assert abs(-Mr[1, 0] - (-e["n_vit"] * Mp[1, 0])) < 1e-9        # same equivalent power


def test_le_grand_cardinal_points_match_textbook():
    # Published Le Grand eye values (Le Grand & El Hage 1980; Schwiegerling 2004):
    # F = 59.94 D, P = 1.595 mm, P' = 1.908 mm, F = -15.089 mm, P'F' = 22.289 mm,
    # N = 7.200 mm, N' = 7.513 mm, emmetropic axial length 24.197 mm.
    cp = m.cardinal_points(m.LE_GRAND)
    assert abs(cp["power_D"] - 59.94) < 0.01
    assert abs(cp["front_principal_P_mm"] - 1.595) < 0.002
    assert abs(cp["back_principal_Pp_mm"] - 1.908) < 0.002
    assert abs(cp["front_focal_F_mm"] - (-15.089)) < 0.002
    assert abs(cp["Pp_to_Fp_mm"] - 22.289) < 0.002
    assert abs(cp["front_nodal_N_mm"] - 7.200) < 0.002
    assert abs(cp["back_nodal_Np_mm"] - 7.513) < 0.002
    assert abs(cp["emmetropic_axial_length_mm"] - 24.19655) < 0.002


def test_three_independent_rx_routes_agree():
    for L in [22.0, 24.19655, 26.0, 28.0, 30.0]:
        a = m.optimal_rx_exact(L)
        b, _ = m.rx_from_cardinal_points(L)
        c = m.rx_step_along_vergence(L)
        assert abs(a - b) < 1e-9 and abs(a - c) < 1e-9


def test_exact_rx_zeroes_every_ray_in_fan():
    for L in [25.0, 28.0]:
        _, _, y = m.ray_fan(L, m.optimal_rx_exact(L), pupil_diameter_mm=6.0)
        assert np.max(np.abs(y)) < 1e-12


def test_on_axis_ray_gives_zero():
    # Reviewer's point: y_in = 0, theta_in = 0 stays on the axis at every Rx.
    assert m.single_ray_intercept_mm(28.0, -3.0, y_in_mm=0.0, theta_in=0.0) == 0.0


def test_spot_radius_linear_in_pupil():
    r3 = m.geometric_spot_radius_mm(27.0, 0.0, 3.0)
    r6 = m.geometric_spot_radius_mm(27.0, 0.0, 6.0)
    assert abs(r6 / r3 - 2.0) < 1e-12


def test_rms_of_uniform_disc():
    r = m.geometric_spot_radius_mm(27.0, 0.0, 4.0)
    rms = m.rms_spot_radius_mm(27.0, 0.0, 4.0, n_grid=801)
    assert abs(rms / r - 1 / np.sqrt(2)) < 2e-3
