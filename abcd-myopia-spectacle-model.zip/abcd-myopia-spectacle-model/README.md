# Supplementary File 1: ABCD-matrix model of the Le Grand eye

Code for "Axial Length and Optimal Spectacle Correction Under a Single-Parameter Model of Axial Elongation: A Paraxial ABCD-Matrix Simulation of the Le Grand Schematic Eye".

## Files
- `abcd_eye_model.py`: matrices, the Le Grand eye, cardinal points, the closed-form optimal spectacle power, two independent vergence checks, and the ray-fan blur measures. The convention is stated at the top of the file.
- `run_analysis.py`: runs every analysis and writes `results/results.json` plus CSV tables (`optimal_rx_exact.csv`, `reference_table.csv`, `vertex_curves.csv`) and `sweep_grid.npz`.
- `make_figures.py`: draws Figures 1 to 4 from the files in `results/` only.
- `tests/test_matrices.py`: unit tests with known answers (single surface, thin lens, thick lens, both matrix conventions, Le Grand cardinal points, agreement of the three optimal-power methods).

## Run
Requires Python 3.10 or later with numpy, scipy, matplotlib and pytest.

```
pip install numpy scipy matplotlib pytest
python -m pytest -q tests
python run_analysis.py
python make_figures.py
```

The whole run takes a few seconds on a laptop.

## Data provenance
There is no measured data. All inputs are the published parameters of the Le Grand full theoretical eye (see Table 1 of the paper) and the simulation settings in `run_analysis.py` (axial length 22 to 30 mm, spectacle power −16 to +6 D, 3 mm pupil, 12 mm vertex distance). The parameter set used in the first submission is kept in `abcd_eye_model.py` as `ORIGINAL_SUBMISSION` only so its numbers can be reproduced.
