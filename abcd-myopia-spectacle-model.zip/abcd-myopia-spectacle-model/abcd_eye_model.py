"""
Paraxial ray-transfer (ABCD) model of a schematic eye with a spectacle lens.

Convention (used everywhere in this file)
----------------------------------------
* Light travels left to right along +z. All distances are in METRES inside the
  functions; public helpers that take "_mm" arguments convert.
* The ray state is [y, theta]: y = height above the axis (m), theta = PHYSICAL
  angle to the axis (rad, paraxial so theta ~ tan theta ~ sin theta).
* Translation through a physical distance d in any medium:
      T(d) = [[1, d], [0, 1]]          (physical d, NOT reduced d/n)
* Refraction at a spherical surface of radius R from index n1 to index n2:
      S(n1, n2, R) = [[1, 0], [(n1 - n2)/(n2 R), n1/n2]]
  derived from paraxial Snell's law n1*i1 = n2*i2 with i = theta + y/R.
  R > 0 when the centre of curvature lies to the right of the vertex.
  Surface power P = (n2 - n1)/R (dioptres when R in metres); P > 0 converges.
* Thin lens in air of power P:  L(P) = [[1, 0], [-P, 1]]  (S with n1 = n2 = 1).
* With this convention det(M) = n_first / n_last, and the equivalent power of
  a system whose last medium has index n' is F = -n' * C.

The alternative "reduced" convention [y, n*theta] uses T = [[1, d/n],[0, 1]] and
S = [[1, 0], [-P, 1]]. Both give identical ray heights; tests/test_matrices.py
checks this.
"""
import numpy as np

# ----------------------------------------------------------------------------
# Le Grand full theoretical (relaxed) eye, four refracting surfaces.
# Source: Y. Le Grand, S.G. El Hage, Physiological Optics (Springer, 1980).
# All values cross-checked against J. Schwiegerling's Visual Optics course notes
# (University of Arizona, 2021, "Gullstrand-LeGrand Eye Model"). Corneal, chamber,
# vitreous and index values also match Table 1 of W.N. Charman, D.A. Atchison,
# Biomed. Opt. Express 5, 31-39 (2014). Book pages not checked directly.
# Distances in mm here, converted to metres below.
# ----------------------------------------------------------------------------
LE_GRAND = {
    "name": "Le Grand full theoretical eye",
    "R_corn_ant_mm": 7.8,
    "R_corn_post_mm": 6.5,
    "R_lens_ant_mm": 10.2,
    "R_lens_post_mm": -6.0,
    "t_corn_mm": 0.55,
    "d_aq_mm": 3.05,
    "t_lens_mm": 4.0,
    "d_vit_textbook_mm": 16.59655,   # textbook vitreous depth (emmetropic eye)
    "n_air": 1.0,
    "n_cornea": 1.3771,
    "n_aq": 1.3374,
    "n_lens": 1.42,
    "n_vit": 1.336,
}

# The parameter set actually run for the ORIGINAL submission (notebook cell 12).
# Kept only so the original numbers can be reproduced and compared.
ORIGINAL_SUBMISSION = {
    "name": "original submission (rounded, lens n=1.406, R_lens_ant=10.0)",
    "R_corn_ant_mm": 7.8,
    "R_corn_post_mm": 6.5,
    "R_lens_ant_mm": 10.0,
    "R_lens_post_mm": -6.0,
    "t_corn_mm": 0.55,
    "d_aq_mm": 3.05,
    "t_lens_mm": 4.0,
    "d_vit_textbook_mm": None,
    "n_air": 1.0,
    "n_cornea": 1.376,
    "n_aq": 1.336,
    "n_lens": 1.406,
    "n_vit": 1.336,
}

DEFAULT_EYE = LE_GRAND
DEFAULT_VERTEX_MM = 12.0


# ------------------------------- elementary matrices ------------------------
def T(d):
    """Translation through physical distance d (m)."""
    return np.array([[1.0, d], [0.0, 1.0]])


def S(n1, n2, R):
    """Refraction at a spherical surface of radius R (m), n1 -> n2."""
    return np.array([[1.0, 0.0], [(n1 - n2) / (n2 * R), n1 / n2]])


def thin_lens(P):
    """Thin lens in air with power P (D)."""
    return np.array([[1.0, 0.0], [-float(P), 1.0]])


def surface_power(n1, n2, R):
    return (n2 - n1) / R


# ------------------------------- eye assembly -------------------------------
def anterior_segment_mm(eye=DEFAULT_EYE):
    return eye["t_corn_mm"] + eye["d_aq_mm"] + eye["t_lens_mm"]


def eye_optics_matrix(eye=DEFAULT_EYE):
    """Anterior cornea vertex -> just after the posterior lens surface (4 surfaces,
    3 translations = 7 matrices)."""
    e = eye
    m = S(e["n_air"], e["n_cornea"], e["R_corn_ant_mm"] * 1e-3)
    m = T(e["t_corn_mm"] * 1e-3) @ m
    m = S(e["n_cornea"], e["n_aq"], e["R_corn_post_mm"] * 1e-3) @ m
    m = T(e["d_aq_mm"] * 1e-3) @ m
    m = S(e["n_aq"], e["n_lens"], e["R_lens_ant_mm"] * 1e-3) @ m
    m = T(e["t_lens_mm"] * 1e-3) @ m
    m = S(e["n_lens"], e["n_vit"], e["R_lens_post_mm"] * 1e-3) @ m
    return m


def eye_matrix(axial_length_mm, eye=DEFAULT_EYE):
    """Corneal vertex -> retina (adds the vitreous translation, 8 matrices)."""
    d_vit = (axial_length_mm - anterior_segment_mm(eye)) * 1e-3
    return T(d_vit) @ eye_optics_matrix(eye)


def system_matrix(axial_length_mm, rx_D, vertex_mm=DEFAULT_VERTEX_MM, eye=DEFAULT_EYE):
    """Full 10-matrix cascade: spectacle lens -> vertex gap -> eye -> retina.
    M_sys = M10 ... M1, with M1 = thin_lens(rx), M2 = T(vertex)."""
    return eye_matrix(axial_length_mm, eye) @ T(vertex_mm * 1e-3) @ thin_lens(rx_D)


def to_stop_matrix(rx_D, vertex_mm=DEFAULT_VERTEX_MM, eye=DEFAULT_EYE):
    """Spectacle lens -> aperture stop. The iris stop is placed at the anterior
    lens surface (vertex), as in the Le Grand eye."""
    e = eye
    m = S(e["n_air"], e["n_cornea"], e["R_corn_ant_mm"] * 1e-3)
    m = T(e["t_corn_mm"] * 1e-3) @ m
    m = S(e["n_cornea"], e["n_aq"], e["R_corn_post_mm"] * 1e-3) @ m
    m = T(e["d_aq_mm"] * 1e-3) @ m
    return m @ T(vertex_mm * 1e-3) @ thin_lens(rx_D)


# ------------------------------- cardinal points ----------------------------
def cardinal_points(eye=DEFAULT_EYE):
    """Paraxial properties of the unaided eye, positions in mm from the
    anterior corneal vertex."""
    m = eye_optics_matrix(eye)
    A, B, C, D = m[0, 0], m[0, 1], m[1, 0], m[1, 1]
    n_in, n_out = eye["n_air"], eye["n_vit"]
    F = -n_out * C                          # equivalent power (D)
    last_vertex_mm = anterior_segment_mm(eye)
    bfd_mm = (-A / C) * 1e3                 # post. lens vertex -> F'
    f_img_mm = (n_out / F) * 1e3            # P'F'
    Fp_mm = last_vertex_mm + bfd_mm         # corneal vertex -> F'
    Pp_mm = Fp_mm - f_img_mm                # corneal vertex -> P'
    ffd_mm = (-D / C) * 1e3                 # object distance in front of cornea for which rays leave parallel
    f_obj_mm = (n_in / F) * 1e3
    F_mm = -ffd_mm                          # front focal point (negative = in front)
    P_mm = F_mm + f_obj_mm                  # front principal point
    N_mm = P_mm + (n_out - n_in) / F * 1e3
    Np_mm = Pp_mm + (n_out - n_in) / F * 1e3
    return {
        "power_D": F,
        "front_principal_P_mm": P_mm,
        "back_principal_Pp_mm": Pp_mm,
        "front_focal_F_mm": F_mm,
        "back_focal_Fp_mm": Fp_mm,
        "back_vertex_focal_distance_mm": bfd_mm,
        "Pp_to_Fp_mm": f_img_mm,
        "front_nodal_N_mm": N_mm,
        "back_nodal_Np_mm": Np_mm,
        "emmetropic_axial_length_mm": Fp_mm,
    }


# ------------------------------- refraction ---------------------------------
def optimal_rx_exact(axial_length_mm, vertex_mm=DEFAULT_VERTEX_MM, eye=DEFAULT_EYE):
    """Spectacle power (D) that images a distant on-axis point onto the retina.

    With eye matrix E = [[a, b], [c, d]] (cornea -> retina) and a parallel input
    ray [h, 0]:  y_retina = h * (a - P (a v + b)).  y_retina = 0 for every h when
    P = a / (a v + b). Closed form, no grid search needed."""
    E = eye_matrix(axial_length_mm, eye)
    a, b = E[0, 0], E[0, 1]
    v = vertex_mm * 1e-3
    return a / (a * v + b)


def rx_from_cardinal_points(axial_length_mm, vertex_mm=DEFAULT_VERTEX_MM, eye=DEFAULT_EYE):
    """Independent route (vergence algebra on the equivalent thick system).
    Ocular refraction referred to the front principal plane P:
        K = n'/l' - F,   l' = axial length - (corneal vertex -> P')
    Spectacle power at distance s = vertex + (corneal vertex -> P) in front of P:
        Rx = K / (1 + s K)."""
    cp = cardinal_points(eye)
    n_out = eye["n_vit"]
    l_img = (axial_length_mm - cp["back_principal_Pp_mm"]) * 1e-3
    K = n_out / l_img - cp["power_D"]
    s = (vertex_mm + cp["front_principal_P_mm"]) * 1e-3
    return K / (1 + s * K), K


def rx_step_along_vergence(axial_length_mm, vertex_mm=DEFAULT_VERTEX_MM, eye=DEFAULT_EYE):
    """Second independent route: surface-by-surface reduced vergence, traced
    BACKWARDS from the retina (the far-point method). No matrices are used."""
    e = eye
    surfaces = [  # (n_before, n_after, R_mm, gap_after_mm)
        (e["n_air"], e["n_cornea"], e["R_corn_ant_mm"], e["t_corn_mm"]),
        (e["n_cornea"], e["n_aq"], e["R_corn_post_mm"], e["d_aq_mm"]),
        (e["n_aq"], e["n_lens"], e["R_lens_ant_mm"], e["t_lens_mm"]),
        (e["n_lens"], e["n_vit"], e["R_lens_post_mm"],
         axial_length_mm - anterior_segment_mm(e)),
    ]
    # Vergence leaving the last surface that focuses on the retina.
    n1, n2, R, gap = surfaces[-1]
    V = n2 / (gap * 1e-3)
    for i in range(len(surfaces) - 1, -1, -1):
        n1, n2, R, gap = surfaces[i]
        U = V - (n2 - n1) / (R * 1e-3)          # vergence arriving at surface i
        if i > 0:
            n_prev_gap = surfaces[i - 1][3] * 1e-3
            # back-propagate through the medium in front (index n1) by n_prev_gap
            V = U / (1 + (n_prev_gap / n1) * U)
        else:
            K_cornea = U                        # vergence needed at the cornea (in air)
    v = vertex_mm * 1e-3
    return K_cornea / (1 + v * K_cornea)


# ------------------------------- blur metrics -------------------------------
def single_ray_intercept_mm(axial_length_mm, rx_D, y_in_mm=1.5, theta_in=0.0,
                            vertex_mm=DEFAULT_VERTEX_MM, eye=DEFAULT_EYE):
    """Original-paper metric: |y_out| for one ray entering the spectacle plane at
    height y_in, angle theta_in. Now called the single-ray intercept error."""
    ray = system_matrix(axial_length_mm, rx_D, vertex_mm, eye) @ np.array([y_in_mm * 1e-3, theta_in])
    return abs(ray[0]) * 1e3


def ray_fan(axial_length_mm, rx_D, pupil_diameter_mm=3.0, n_rays=41,
            vertex_mm=DEFAULT_VERTEX_MM, eye=DEFAULT_EYE):
    """Trace a meridional fan of rays from a distant on-axis point that fills a
    real pupil (aperture stop at the anterior lens surface) of the given
    diameter. Returns (stop heights mm, spectacle-plane heights mm, retinal
    heights mm)."""
    Ms = to_stop_matrix(rx_D, vertex_mm, eye)
    k = Ms[0, 0]                                        # stop height per unit input height
    stop_h = np.linspace(-pupil_diameter_mm / 2, pupil_diameter_mm / 2, n_rays)
    in_h = stop_h / k
    M = system_matrix(axial_length_mm, rx_D, vertex_mm, eye)
    rays_in = np.vstack([in_h * 1e-3, np.zeros_like(in_h)])
    y_ret = (M @ rays_in)[0] * 1e3
    return stop_h, in_h, y_ret


def geometric_spot_radius_mm(axial_length_mm, rx_D, pupil_diameter_mm=3.0,
                             vertex_mm=DEFAULT_VERTEX_MM, eye=DEFAULT_EYE):
    """Radius of the paraxial geometric blur disc = largest |retinal height|
    over the traced fan (the marginal ray)."""
    _, _, y = ray_fan(axial_length_mm, rx_D, pupil_diameter_mm, 41, vertex_mm, eye)
    return float(np.max(np.abs(y)))


def rms_spot_radius_mm(axial_length_mm, rx_D, pupil_diameter_mm=3.0, n_grid=201,
                       vertex_mm=DEFAULT_VERTEX_MM, eye=DEFAULT_EYE):
    """RMS spot radius from a 2-D square grid of rays filling the circular pupil.
    In a centred paraxial system x and y map independently with the same factor."""
    r = pupil_diameter_mm / 2
    g = np.linspace(-r, r, n_grid)
    X, Y = np.meshgrid(g, g)
    inside = X**2 + Y**2 <= r**2
    Ms = to_stop_matrix(rx_D, vertex_mm, eye)
    M = system_matrix(axial_length_mm, rx_D, vertex_mm, eye)
    scale = M[0, 0] / Ms[0, 0]                       # retina height per stop height
    xr, yr = X[inside] * scale, Y[inside] * scale
    return float(np.sqrt(np.mean(xr**2 + yr**2)))
