"""
Draws every figure ONLY from the frozen outputs in results/ (never re-simulates),
so figures, legends and text all come from one dataset.

Usage:  python run_analysis.py && python make_figures.py
"""
import json, csv, pathlib
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

HERE = pathlib.Path(__file__).resolve().parent
RES, FIG = HERE / "results", HERE / "figures"
FIG.mkdir(exist_ok=True)
R = json.loads((RES / "results.json").read_text())
G = np.load(RES / "sweep_grid.npz")

BLUE, ORANGE = "#2a78d6", "#eb6834"
INK, MUTED, GRID = "#222222", "#6b6b6b", "#e4e4e4"
SEQ = LinearSegmentedColormap.from_list(
    "blue_seq", ["#f7fbff", "#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#256abf", "#184f95", "#0d366b"])
plt.rcParams.update({"figure.dpi": 150, "savefig.dpi": 300, "font.family": "DejaVu Sans",
                     "font.size": 10, "axes.labelsize": 11, "axes.titlesize": 11,
                     "axes.edgecolor": MUTED, "axes.labelcolor": INK, "xtick.color": MUTED,
                     "ytick.color": MUTED, "axes.spines.top": False, "axes.spines.right": False,
                     "legend.frameon": False, "lines.linewidth": 2})

def read_csv(name):
    with open(RES / name) as f:
        rows = list(csv.DictReader(f))
    return {k: np.array([float(r[k]) for r in rows]) for k in rows[0]}

ex = read_csv("optimal_rx_exact.csv")
L0 = R["baseline_le_grand"]["emmetropic_axial_length_mm"]
pupil = R["settings"]["pupil_diameter_mm"]
fitm = R["fit_exact_myopic_range"]

# ---------------------------------------------------------------- Figure 1
fig, ax = plt.subplots(figsize=(7.5, 5))
im = ax.pcolormesh(G["rx_powers"], G["axial_lengths"], G["spot_radius_mm"], cmap=SEQ, shading="nearest")
cb = fig.colorbar(im, ax=ax)
cb.set_label(f"Geometric spot radius, {pupil:.0f} mm pupil (mm)")
ax.plot(ex["optimal_rx_D"], ex["axial_length_mm"], color=ORANGE, lw=2, label="Exact optimal Rx")
for L, lab in [(L0, f"{L0:.2f} mm (model emmetropia)"), (26.0, "26 mm"), (28.0, "28 mm"), (30.0, "30 mm")]:
    ax.axhline(L, color=INK, lw=0.6, ls="--", alpha=0.5)
    top = L >= 29.9
    ax.text(G["rx_powers"].max() - 0.2, L - 0.07 if top else L + 0.07, lab, ha="right",
            va="top" if top else "bottom", fontsize=8, color=INK)
ax.axvline(0, color=INK, lw=0.6, ls=":", alpha=0.6)
ax.set_xlabel("Spectacle lens power, Rx (D)")
ax.set_ylabel("Axial length (mm)")
ax.legend(loc="lower left", fontsize=9)
fig.tight_layout(); fig.savefig(FIG / "fig1_spot_heatmap.png"); plt.close(fig)

# ---------------------------------------------------------------- Figure 2 (two stacked panels, shared x)
fig, (ax, axr) = plt.subplots(2, 1, figsize=(7.5, 6), sharex=True, gridspec_kw={"height_ratios": [3, 1]})
ax.plot(ex["axial_length_mm"], ex["optimal_rx_D"], color=BLUE, label="Exact optimal Rx (closed form)")
m_ = G["axial_lengths"] >= 0
ax.scatter(G["axial_lengths"], G["best_rx_grid"], s=22, facecolor="white", edgecolor=BLUE, lw=1.2, zorder=3,
           label="Grid search (0.2 mm x 0.25 D)")
xs = np.array(fitm["range_mm"])
ax.plot(xs, fitm["slope_D_per_mm"] * xs + fitm["intercept_D"], color=ORANGE, ls="--", lw=1.8,
        label=(f"Linear fit {fitm['range_mm'][0]:.1f}-{fitm['range_mm'][1]:.0f} mm: "
               f"Rx = {fitm['slope_D_per_mm']:.3f}L + {fitm['intercept_D']:.2f}"))
for y, lab in [(-0.5, "-0.50 D myopia threshold"), (-6.0, "-6.00 D high-myopia threshold")]:
    ax.axhline(y, color=MUTED, lw=0.8, ls=":")
    ax.text(22.05, y + 0.25, lab, fontsize=8, color=MUTED)
ax.axvline(L0, color=MUTED, lw=0.8, ls=":")
ax.set_ylabel("Optimal spectacle Rx (D)")
ax.legend(loc="lower left", fontsize=8.5)
ax.grid(axis="y", color=GRID, lw=0.6)
Lf, rf = ex["axial_length_mm"], ex["optimal_rx_D"]
sel = Lf >= L0
axr.plot(Lf[sel], rf[sel] - (fitm["slope_D_per_mm"] * Lf[sel] + fitm["intercept_D"]), color=BLUE)
axr.axhline(0, color=MUTED, lw=0.8)
axr.set_ylabel("Residual (D)")
axr.set_xlabel("Axial length (mm)")
axr.set_xlim(22, 30)
axr.grid(axis="y", color=GRID, lw=0.6)
fig.tight_layout(); fig.savefig(FIG / "fig2_optimal_rx.png"); plt.close(fig)

# ---------------------------------------------------------------- Figure 3
rows = [r for r in R["reference_table"] if r["axial_length_mm"] > L0 + 1e-6]
x = np.arange(len(rows)); w = 0.36
unc = [r["spot_uncorrected_mm"] * 1e3 for r in rows]
cor = [r["spot_rounded_rx_mm"] * 1e3 for r in rows]
fig, ax = plt.subplots(figsize=(7.5, 4.6))
b1 = ax.bar(x - w / 2 - 0.01, unc, w, color=BLUE, label="Uncorrected (Rx = 0 D)")
b2 = ax.bar(x + w / 2 + 0.01, cor, w, color=ORANGE, label="Corrected, Rx rounded to 0.25 D")
for b, v in zip(b1, unc):
    ax.text(b.get_x() + b.get_width() / 2, v + 4, f"{v:.0f}", ha="center", fontsize=9, color=INK)
for b, v in zip(b2, cor):
    ax.text(b.get_x() + b.get_width() / 2, v + 4, f"{v:.1f}", ha="center", fontsize=9, color=INK)
labels = [f"{r['axial_length_mm']:.1f} mm\nRx {r['optimal_rx_D']:.2f} D\n{r['model_state'].split(' (')[0]}" for r in rows]
ax.set_xticks(x); ax.set_xticklabels(labels, fontsize=8.5)
ax.set_ylabel(f"Geometric spot radius, {pupil:.0f} mm pupil (µm)")
ax.set_ylim(0, max(unc) * 1.15)
ax.legend(loc="upper left", fontsize=9)
ax.grid(axis="y", color=GRID, lw=0.6); ax.set_axisbelow(True)
fig.tight_layout(); fig.savefig(FIG / "fig3_corrected_vs_uncorrected.png"); plt.close(fig)

# ---------------------------------------------------------------- Figure 4 (two panels, separate y-axes, side by side)
ps = R["pupil_sensitivity"]["spot_uncorrected_mm"]
diam = [float(k.replace("mm_pupil", "")) for k in ps]
fig, (a1, a2) = plt.subplots(1, 2, figsize=(9, 3.8))
for L, c, mk in [("26.0", BLUE, "o"), ("28.0", ORANGE, "s"), ("30.0", "#1baf7a", "^")]:
    a1.plot(diam, [ps[k][L] * 1e3 for k in ps], color=c, marker=mk, ms=6, label=f"{L} mm, uncorrected")
a1.set_xlabel("Pupil diameter (mm)"); a1.set_ylabel("Geometric spot radius (µm)")
a1.set_title("(a) Spot radius scales with pupil", loc="left")
a1.legend(fontsize=8.5); a1.grid(color=GRID, lw=0.6)
vc = read_csv("vertex_curves.csv")
for key, lab, c, ls in [("rx_v10", "10 mm vertex", BLUE, "-"), ("rx_v14", "14 mm vertex", ORANGE, "-"),
                        ("rx_v0", "0 mm (corneal plane)", MUTED, "--")]:
    a2.plot(vc["axial_length_mm"], vc[key] - vc["rx_v12"], color=c, ls=ls, label=lab)
a2.axhline(0, color=INK, lw=0.6)
a2.set_xlabel("Axial length (mm)"); a2.set_ylabel("Rx minus Rx at 12 mm vertex (D)")
a2.set_title("(b) Effect of vertex distance", loc="left")
a2.legend(fontsize=8.5); a2.grid(color=GRID, lw=0.6)
fig.tight_layout(); fig.savefig(FIG / "fig4_pupil_and_vertex.png"); plt.close(fig)
print("figures written to", FIG)
