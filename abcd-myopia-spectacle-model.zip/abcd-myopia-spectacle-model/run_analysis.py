"""
Runs every analysis in the paper and writes ONE frozen output file:
    results/results.json   (+ CSV copies of each table)
Figures (make_figures.py) and every number in the manuscript are read from it.

Usage:  python run_analysis.py
"""
import json, csv, pathlib, platform
import numpy as np
from scipy.stats import linregress
import abcd_eye_model as m

OUT = pathlib.Path(__file__).resolve().parent / "results"
OUT.mkdir(exist_ok=True)
EYE = m.LE_GRAND
PUPIL_MM = 3.0            # default pupil diameter for the geometric spot
Y_IN_MM = 1.5             # input height used by the original single-ray metric
VERTEX_MM = 12.0
REF_L = [24.5, 26.0, 28.0, 30.0]
R = {}

# ---------------------------------------------------------------- 1 baseline
cp = m.cardinal_points(EYE)
L0 = cp["emmetropic_axial_length_mm"]
R["baseline_le_grand"] = cp
R["baseline_original_submission"] = m.cardinal_points(m.ORIGINAL_SUBMISSION)
R["textbook_le_grand"] = {"power_D": 59.94, "front_principal_P_mm": 1.595, "back_principal_Pp_mm": 1.908,
                          "front_focal_F_mm": -15.089, "Pp_to_Fp_mm": 22.289, "front_nodal_N_mm": 7.200,
                          "back_nodal_Np_mm": 7.513, "emmetropic_axial_length_mm": 24.19655}
R["settings"] = {"eye": EYE["name"], "pupil_diameter_mm": PUPIL_MM, "vertex_mm": VERTEX_MM,
                 "stop": "anterior lens surface", "object": "on-axis point at infinity",
                 "original_metric_input_ray": {"y_in_mm": Y_IN_MM, "theta_in_rad": 0.0,
                                               "plane": "spectacle lens"},
                 "python": platform.python_version(), "numpy": np.__version__}

# ---------------------------------------------------------------- 2 exact curve
L_fine = np.round(np.arange(22.0, 30.0001, 0.01), 2)
rx_exact = np.array([m.optimal_rx_exact(L, VERTEX_MM, EYE) for L in L_fine])
checks_cp = np.array([m.rx_from_cardinal_points(L, VERTEX_MM, EYE)[0] for L in L_fine])
checks_va = np.array([m.rx_step_along_vergence(L, VERTEX_MM, EYE) for L in L_fine])
R["independent_checks_max_abs_diff_D"] = {
    "cardinal_point_vergence": float(np.max(np.abs(rx_exact - checks_cp))),
    "step_along_vergence": float(np.max(np.abs(rx_exact - checks_va)))}
with open(OUT / "optimal_rx_exact.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["axial_length_mm", "optimal_rx_D"])
    w.writerows([[f"{L:.2f}", f"{p:.6f}"] for L, p in zip(L_fine, rx_exact)])

def L_at_rx(target):
    """Axial length at which the exact optimal Rx equals target (D)."""
    return float(np.interp(-target, -rx_exact, L_fine))
R["axial_length_at_rx_mm"] = {str(t): L_at_rx(t) for t in [0.0, -0.5, -3.0, -6.0, -10.0]}

# local slope dRx/dL (D/mm), central difference on exact function
def local_slope(L, h=1e-3):
    return (m.optimal_rx_exact(L + h, VERTEX_MM, EYE) - m.optimal_rx_exact(L - h, VERTEX_MM, EYE)) / (2 * h)
R["local_slope_D_per_mm"] = {f"{L:.2f}": local_slope(L) for L in [22.0, L0, 26.0, 28.0, 30.0]}

# ---------------------------------------------------------------- 3 linear fits
def fit(Ls, rxs):
    s, i, r, _, se = linregress(Ls, rxs)
    res = rxs - (s * Ls + i)
    return {"slope_D_per_mm": s, "intercept_D": i, "r_squared": r * r, "slope_se": se,
            "max_abs_residual_D": float(np.max(np.abs(res))), "n_points": int(len(Ls)),
            "range_mm": [float(Ls.min()), float(Ls.max())]}

L_grid = np.round(np.arange(22.0, 30.0001, 0.2), 1)             # 41 points, as in the paper
myo = L_grid >= L0
rx_on_grid = np.array([m.optimal_rx_exact(L, VERTEX_MM, EYE) for L in L_grid])
R["fit_exact_myopic_range"] = fit(L_grid[myo], rx_on_grid[myo])
R["fit_exact_full_range"] = fit(L_grid, rx_on_grid)
q = np.polyfit(L_grid[myo], rx_on_grid[myo], 2)
R["quadratic_fit_myopic_range"] = {"a2": q[0], "a1": q[1], "a0": q[2]}

# ---------------------------------------------------------------- 4 grid search (original method) + halved grid
def grid_search(dL, dP, P_lo=-16.0, P_hi=6.0):
    Ls = np.round(np.arange(22.0, 30.0 + dL / 2, dL), 4)
    Ps = np.round(np.arange(P_lo, P_hi + dP / 2, dP), 4)
    spot = np.array([[m.geometric_spot_radius_mm(L, P, PUPIL_MM, VERTEX_MM, EYE) for P in Ps] for L in Ls])
    best = Ps[np.argmin(spot, axis=1)]
    return Ls, Ps, spot, best

Lg, Pg, spot_grid, best_g = grid_search(0.2, 0.25)
Lh, Ph, _, best_h = grid_search(0.1, 0.125)
np.savez(OUT / "sweep_grid.npz", axial_lengths=Lg, rx_powers=Pg, spot_radius_mm=spot_grid,
         best_rx_grid=best_g, axial_half=Lh, best_rx_half=best_h)
R["sweep"] = {"axial_step_mm": 0.2, "rx_step_D": 0.25, "rx_range_D": [float(Pg.min()), float(Pg.max())],
              "n_axial": int(len(Lg)), "n_rx": int(len(Pg)), "n_combinations": int(spot_grid.size),
              "spot_min_mm": float(spot_grid.min()), "spot_max_mm": float(spot_grid.max())}
mg, mh = Lg >= L0, Lh >= L0
R["fit_grid_search_0p2mm_0p25D"] = fit(Lg[mg], best_g[mg])
R["fit_grid_search_0p1mm_0p125D"] = fit(Lh[mh], best_h[mh])
R["grid_vs_exact_max_abs_diff_D"] = {
    "0.25D_grid": float(np.max(np.abs(best_g - np.array([m.optimal_rx_exact(L) for L in Lg])))),
    "0.125D_grid": float(np.max(np.abs(best_h - np.array([m.optimal_rx_exact(L) for L in Lh]))))}

# ---------------------------------------------------------------- 5 reference-length summary table
def model_state(rx):
    # Labels come from the model's own refraction, not from axial length.
    if abs(rx) < 1e-9: return "emmetropic (0 D by definition)"
    if rx > -0.5 and rx < 0.5: return "near-emmetropic (|Rx| < 0.50 D)"
    if rx >= 0.5: return "hyperopic"
    if rx > -6.0: return "low myopia (-0.50 to -6.00 D)"
    return "high myopia (<= -6.00 D)"

rows = []
for L in [L0] + REF_L:
    rx = m.optimal_rx_exact(L, VERTEX_MM, EYE)
    rx_q = round(rx * 4) / 4
    K = m.rx_from_cardinal_points(L, 0.0, EYE)[0]          # refraction at corneal plane (vertex 0)
    rows.append({
        "axial_length_mm": L, "model_state": model_state(rx),
        "optimal_rx_D": rx, "rx_rounded_0p25_D": rx_q, "corneal_plane_refraction_D": K,
        "spot_uncorrected_mm": m.geometric_spot_radius_mm(L, 0.0, PUPIL_MM, VERTEX_MM, EYE),
        "spot_rounded_rx_mm": m.geometric_spot_radius_mm(L, rx_q, PUPIL_MM, VERTEX_MM, EYE),
        "spot_exact_rx_mm": m.geometric_spot_radius_mm(L, rx, PUPIL_MM, VERTEX_MM, EYE),
        "rms_uncorrected_mm": m.rms_spot_radius_mm(L, 0.0, PUPIL_MM, 401, VERTEX_MM, EYE),
        "single_ray_intercept_uncorrected_mm": m.single_ray_intercept_mm(L, 0.0, Y_IN_MM, 0.0, VERTEX_MM, EYE),
    })
R["reference_table"] = rows
with open(OUT / "reference_table.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

# ---------------------------------------------------------------- 6 pupil sensitivity
R["pupil_sensitivity"] = {
    "optimal_rx_depends_on_pupil": False,
    "note": "paraxial: every ray in the fan scales by the same factor, so the Rx that zeroes one ray zeroes all",
    "spot_uncorrected_mm": {f"{d:.0f}mm_pupil": {f"{L:.1f}": m.geometric_spot_radius_mm(L, 0.0, d, VERTEX_MM, EYE)
                                                for L in [26.0, 28.0, 30.0]} for d in [2.0, 3.0, 4.0, 6.0]},
}
# numeric check: for each pupil, minimise the spot radius on a 0.001 D grid (no closed form used)
Pfine = np.arange(-16.0, 6.00001, 0.001)
R["pupil_sensitivity"]["numeric_best_rx_D"] = {
    f"{d:.0f}mm_pupil": {f"{L:.1f}": float(Pfine[np.argmin([m.geometric_spot_radius_mm(L, P, d, VERTEX_MM, EYE)
                                                             for P in Pfine])]) for L in [26.0, 28.0]}
    for d in [2.0, 3.0, 4.0, 6.0]}

# ---------------------------------------------------------------- 7 vertex-distance sensitivity
vt = {}
for v in [10.0, 12.0, 14.0]:
    rx_v = np.array([m.optimal_rx_exact(L, v, EYE) for L in L_grid])
    vt[f"{v:.0f}"] = {"rx_at_L_D": {f"{L:.1f}": m.optimal_rx_exact(L, v, EYE) for L in REF_L},
                      "fit_myopic_range": fit(L_grid[myo], rx_v[myo])}
with open(OUT / "vertex_curves.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["axial_length_mm", "rx_v0", "rx_v10", "rx_v12", "rx_v14"])
    for L in L_fine:
        w.writerow([f"{L:.2f}"] + [f"{m.optimal_rx_exact(L, v, EYE):.6f}" for v in [0.0, 10.0, 12.0, 14.0]])
vt["contact_lens_plane_0mm"] = {"rx_at_L_D": {f"{L:.1f}": m.optimal_rx_exact(L, 0.0, EYE) for L in REF_L}}
R["vertex_sensitivity"] = vt

# ---------------------------------------------------------------- 8 analytic approximations
Pp = cp["back_principal_Pp_mm"]; F = cp["power_D"]; nv = EYE["n_vit"]
R["analytic"] = {
    "exact_formula": "Rx = K/(1 + sK), K = n'/(L - P') - F, s = vertex + P",
    "slope_at_cornea_plane_n_over_lprime2_D_per_mm": {f"{L:.1f}": -nv / ((L - Pp) * 1e-3) ** 2 * 1e-3
                                                      for L in [L0, 26.0, 28.0]},
    "original_paper_approx_minus_n_over_L2_D_per_mm_at_25mm": -nv / (25e-3) ** 2 * 1e-3,
    "original_paper_approx_minus_n_over_L2_D_per_mm_at_L0": -nv / (L0 * 1e-3) ** 2 * 1e-3,
}

# ---------------------------------------------------------------- 9 reproduction of the original submission
def orig_rx(L): return m.optimal_rx_exact(L, VERTEX_MM, m.ORIGINAL_SUBMISSION)
Lo = np.round(np.arange(24.5, 28.0001, 0.25), 2)
R["original_submission_reproduced"] = {
    "fit_24p5_28": fit(Lo, np.array([orig_rx(L) for L in Lo])),
    "rx_at": {f"{L:.1f}": orig_rx(L) for L in [24.5, 25.5, 26.5, 28.0]},
    "single_ray_uncorrected_mm": {f"{L:.1f}": m.single_ray_intercept_mm(L, 0.0, 1.5, 0.0, VERTEX_MM, m.ORIGINAL_SUBMISSION)
                                  for L in [24.5, 25.5, 26.5, 28.0]},
}

def clean(o):
    if isinstance(o, dict): return {k: clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)): return [clean(v) for v in o]
    if isinstance(o, (np.floating,)): return float(o)
    if isinstance(o, (np.integer,)): return int(o)
    if isinstance(o, np.bool_): return bool(o)
    return o

(OUT / "results.json").write_text(json.dumps(clean(R), indent=2))
print("wrote", OUT / "results.json")
